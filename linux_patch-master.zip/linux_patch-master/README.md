# linux_patch
Ansible script for patching linux server
